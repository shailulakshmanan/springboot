package com.example.vehicle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleInsuranceProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
